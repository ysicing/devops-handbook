# 安装方法
```
1. master上： cd shell && sh init.sh && sh master.sh
2. node上：cd shell && sh init.sh
3. 在node上执行master输出的join命令即可 (命令忘记了可以用这个查看，kubeadm token create --print-join-command)
```

# 安装常见问题请见下面连接评论区
http://sealyun.com/pro/products/  [评论区](http://sealyun.com/pro/products/)
